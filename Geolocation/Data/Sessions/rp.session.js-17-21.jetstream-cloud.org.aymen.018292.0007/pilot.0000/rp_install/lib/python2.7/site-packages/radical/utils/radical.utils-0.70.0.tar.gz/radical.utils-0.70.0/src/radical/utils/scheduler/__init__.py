
__author__    = "Radical.Utils Development Team"
__copyright__ = "Copyright 2013, RADICAL@Rutgers"
__license__   = "MIT"


from .scheduler_bitarray import BitarrayScheduler

