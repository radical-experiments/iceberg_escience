
( 
 ( 
  sh daemonized.sh 
 ) &
)


